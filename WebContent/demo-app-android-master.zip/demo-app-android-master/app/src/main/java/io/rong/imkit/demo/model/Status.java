package io.rong.imkit.demo.model;

import java.io.Serializable;

public class Status implements Serializable {
	
	private int code;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}
	

}
